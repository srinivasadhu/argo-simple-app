# Security Scanning with Checkov

This document explains the security scanning setup for the ALB Terraform module using Checkov.

## Overview

This repository uses [Checkov](https://www.checkov.io/) to automatically scan Terraform configurations for security and compliance issues. Scans are triggered automatically on pull requests and can also be run locally during development.

## Automated Scanning

### GitHub Actions Workflow

The `.github/workflows/checkov.yml` workflow automatically runs when:
- A pull request is created targeting the `main` branch
- Terraform files (`.tf`, `.tfvars`, `.tfvars.example`) are modified
- The workflow file itself is modified

### What Gets Scanned

1. **Root Module** - Main Terraform module files
2. **Basic Example** - Simple ALB example in `examples/basic/`
3. **Multi-Target-Group Example** - Advanced example in `examples/multi_target_group_alb/`

### Workflow Features

- **Security Scanning** - Identifies security misconfigurations
- **SARIF Upload** - Results uploaded to GitHub Security tab
- **PR Comments** - Automatic comments with scan results
- **Baseline Comparison** - Compares findings against main branch
- **Soft Fail** - Doesn't block PRs, but highlights issues

## Local Development Scanning

### Prerequisites

Install Checkov:
```bash
pip install checkov
```

### Running Scans Locally

#### Option 1: Use the provided scripts

**Linux/macOS:**
```bash
./scripts/run-checkov.sh
```

**Windows PowerShell:**
```powershell
.\scripts\run-checkov.ps1
```

#### Option 2: Run Checkov directly

**Scan root module:**
```bash
checkov --framework terraform --directory . --config-file .checkov.yml
```

**Scan specific example:**
```bash
checkov --framework terraform --directory examples/basic --config-file .checkov.yml
```

**Scan with specific output format:**
```bash
checkov --framework terraform \
        --directory . \
        --output cli \
        --output sarif \
        --output-file-path console,results.sarif \
        --config-file .checkov.yml
```

## Configuration

### Checkov Configuration File

The `.checkov.yml` file contains the scanning configuration:

- **Skipped Checks** - Intentionally disabled checks with justification
- **Output Formats** - CLI, JSON, and SARIF outputs
- **Exclusions** - Directories and files to skip
- **Soft Fail Mode** - Don't fail builds on findings

### Intentionally Skipped Checks

Some checks are skipped because they're handled by the module or not applicable:

| Check ID | Description | Reason |
|----------|-------------|---------|
| `CKV_AWS_18` | S3 bucket access logging | Handled by module |
| `CKV_AWS_21` | S3 bucket versioning | Handled by module |
| `CKV_AWS_91` | ALB access logs encryption | Handled by module |
| `CKV_AWS_92` | ALB access logs versioning | Handled by module |
| `CKV_AWS_144` | S3 public read access | Handled by module |
| `CKV_AWS_145` | S3 public write access | Handled by module |
| `CKV_AWS_260` | Security group 0.0.0.0/0 | Examples need public access |

## Understanding Results

### Severity Levels

- **CRITICAL** - Must be fixed before production deployment
- **HIGH** - Should be addressed before merging
- **MEDIUM** - Consider addressing based on risk assessment
- **LOW** - Optional improvements
- **INFO** - Informational findings

### Result Formats

#### CLI Output
Human-readable output showing:
- Check results (PASSED/FAILED)
- File locations
- Remediation guidance

#### SARIF Output
Machine-readable format for:
- GitHub Security tab integration
- IDE integration
- Automated processing

#### JSON Output
Detailed structured data including:
- Complete check results
- Metadata and statistics
- Resource details

## GitHub Security Integration

### Viewing Results

1. Go to the **Security** tab in your GitHub repository
2. Click on **Code scanning alerts**
3. Filter by **Checkov** to see security findings
4. Click on individual alerts for details and remediation guidance

### Managing Alerts

- **Dismiss** false positives with justification
- **Create issues** for findings that need attention
- **Track remediation** progress over time

## Best Practices

### For Developers

1. **Run scans locally** before creating PRs
2. **Address critical and high findings** before requesting review
3. **Document suppressions** with clear justification
4. **Review baseline comparisons** in PR comments

### For Reviewers

1. **Check security tab** for new findings
2. **Verify suppressions** are justified
3. **Ensure critical issues** are addressed
4. **Consider security impact** of changes

### For Maintainers

1. **Regularly update** Checkov version
2. **Review skipped checks** periodically
3. **Monitor security trends** over time
4. **Update configuration** as needed

## Troubleshooting

### Common Issues

#### Checkov Not Found
```bash
pip install checkov
# or
pip3 install checkov
```

#### Permission Denied (Linux/macOS)
```bash
chmod +x scripts/run-checkov.sh
```

#### PowerShell Execution Policy (Windows)
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

#### False Positives
Add to `.checkov.yml` skip-check section with justification:
```yaml
skip-check:
  - CKV_AWS_XXX  # Justification for skipping this check
```

### Getting Help

- **Checkov Documentation**: https://www.checkov.io/
- **GitHub Issues**: Report issues with the scanning setup
- **Security Team**: Contact for security-related questions

## Customization

### Adding Custom Checks

1. Create custom policies in `.checkov/policies/`
2. Update `.checkov.yml` to include custom checks directory
3. Test locally before committing

### Modifying Scan Scope

Update `.github/workflows/checkov.yml` to:
- Add/remove directories
- Change trigger conditions
- Modify output formats
- Adjust failure conditions

### Integration with Other Tools

The SARIF output can be consumed by:
- **GitHub Advanced Security**
- **Azure DevOps**
- **SonarQube**
- **IDE extensions**
- **Custom tooling**

## Security Policy

This scanning setup is part of our security policy:

1. **All code changes** must pass security scanning
2. **Critical findings** must be addressed before merging
3. **Suppressions** require justification and approval
4. **Regular reviews** of security posture and findings

For more information, see our [Security Policy](../SECURITY.md).