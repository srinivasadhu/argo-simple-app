# AWS Application Load Balancer (ALB) Terraform Module

A comprehensive Terraform module for creating and managing AWS Application Load Balancers with support for multiple target groups, advanced routing rules, and production-ready configurations.

## Features

- **🚀 Multiple Target Groups**: Support for multiple target groups with individual health checks and routing rules
- **🔀 Advanced Routing**: Path-based, host-based, and HTTP method-based routing with listener rules
- **🔒 Security**: Built-in security groups, SSL/TLS support, and security best practices
- **📊 Monitoring**: Access logs, CloudWatch integration, and comprehensive outputs
- **⚡ Performance**: HTTP/2 support, cross-zone load balancing, and configurable algorithms
- **🏷️ Flexible Naming**: Consistent resource naming with customizable patterns
- **🎯 Production Ready**: Deletion protection, health checks, and graceful deployments

## Usage

### Basic Example

```hcl
module "alb" {
  source = "path/to/this/module"

  # Network Configuration
  vpc_id     = "vpc-12345678"
  subnet_ids = ["subnet-12345678", "subnet-87654321"]

  # Basic ALB Configuration
  internal      = false
  http_enabled  = true
  https_enabled = true
  certificate_arn = "arn:aws:acm:us-west-1:123456789012:certificate/12345678-1234-1234-1234-123456789012"

  # Naming
  namespace   = "mycompany"
  environment = "prod"
  name        = "web-alb"

  tags = {
    Environment = "production"
    Team        = "platform"
  }
}
```

### Advanced Example with Multiple Target Groups

```hcl
module "alb" {
  source = "path/to/this/module"

  # Network Configuration
  vpc_id     = "vpc-12345678"
  subnet_ids = ["subnet-12345678", "subnet-87654321"]

  # ALB Configuration
  internal       = false
  http_enabled   = true
  http_redirect  = true
  https_enabled  = true
  certificate_arn = "arn:aws:acm:us-west-1:123456789012:certificate/12345678-1234-1234-1234-123456789012"

  # Multiple Target Groups
  target_groups = {
    frontend = {
      port         = 80
      protocol     = "HTTP"
      target_type  = "instance"
      
      health_check = {
        path                = "/health"
        healthy_threshold   = 2
        unhealthy_threshold = 3
        timeout             = 5
        interval            = 30
        matcher             = "200"
      }
    }
    
    api = {
      port         = 8080
      protocol     = "HTTP"
      target_type  = "ip"
      
      health_check = {
        path                = "/api/health"
        healthy_threshold   = 2
        unhealthy_threshold = 5
        timeout             = 10
        interval            = 30
        matcher             = "200,202"
      }
    }
  }

  # Listener Rules for Routing
  listener_rules = {
    api_rule = {
      listener_type    = "https"
      priority         = 100
      target_group_key = "api"
      
      conditions = [
        {
          field  = "path-pattern"
          values = ["/api/*"]
        }
      ]
    }
    
    default_rule = {
      listener_type    = "https"
      priority         = 1000
      target_group_key = "frontend"
      
      conditions = [
        {
          field  = "path-pattern"
          values = ["/*"]
        }
      ]
    }
  }

  # Naming and Tagging
  namespace   = "mycompany"
  environment = "prod"
  name        = "web-alb"
  
  tags = {
    Environment = "production"
    Team        = "platform"
    Project     = "web-app"
  }
}
```

## Examples

- [**Basic ALB**](./examples/basic) - Simple ALB with default target group
- [**Multiple Target Groups**](./examples/multi_target_group_alb) - Advanced routing with multiple services

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.3 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 5.99 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | >= 5.99 |

## Resources

| Name | Type |
|------|------|
| [aws_lb.default](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb) | resource |
| [aws_lb_listener.http_forward](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_listener) | resource |
| [aws_lb_listener.http_redirect](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_listener) | resource |
| [aws_lb_listener.https](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_listener) | resource |
| [aws_lb_listener_certificate.https_sni](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_listener_certificate) | resource |
| [aws_lb_listener_rule.rules](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_listener_rule) | resource |
| [aws_lb_target_group.additional](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_target_group) | resource |
| [aws_lb_target_group.default](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_target_group) | resource |
| [aws_s3_bucket.access_logs](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket) | resource |
| [aws_s3_bucket_lifecycle_configuration.default](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_lifecycle_configuration) | resource |
| [aws_s3_bucket_policy.default](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_policy) | resource |
| [aws_s3_bucket_public_access_block.default](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_public_access_block) | resource |
| [aws_s3_bucket_server_side_encryption_configuration.default](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_server_side_encryption_configuration) | resource |
| [aws_security_group.default](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [aws_security_group_rule.egress](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.http_ingress](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.https_ingress](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | VPC ID to associate with ALB | `string` | n/a | yes |
| <a name="input_subnet_ids"></a> [subnet\_ids](#input\_subnet\_ids) | A list of subnet IDs to associate with ALB | `list(string)` | n/a | yes |
| <a name="input_internal"></a> [internal](#input\_internal) | A boolean flag to determine whether the ALB should be internal | `bool` | `false` | no |
| <a name="input_http_enabled"></a> [http\_enabled](#input\_http\_enabled) | A boolean flag to enable/disable HTTP listener | `bool` | `true` | no |
| <a name="input_http_redirect"></a> [http\_redirect](#input\_http\_redirect) | A boolean flag to enable/disable HTTP redirect to HTTPS | `bool` | `false` | no |
| <a name="input_https_enabled"></a> [https\_enabled](#input\_https\_enabled) | A boolean flag to enable/disable HTTPS listener | `bool` | `false` | no |
| <a name="input_certificate_arn"></a> [certificate\_arn](#input\_certificate\_arn) | The ARN of the default SSL certificate for HTTPS listener | `string` | `""` | no |
| <a name="input_target_groups"></a> [target\_groups](#input\_target\_groups) | Map of target group configurations. Key is used as target group identifier. | <pre>map(object({<br>    name                              = optional(string)<br>    port                              = number<br>    protocol                          = string<br>    protocol_version                  = optional(string, "HTTP1")<br>    target_type                       = optional(string, "instance")<br>    load_balancing_algorithm_type     = optional(string, "round_robin")<br>    load_balancing_anomaly_mitigation = optional(string, "off")<br>    deregistration_delay              = optional(number, 15)<br>    slow_start                        = optional(number, 0)<br>    <br>    health_check = optional(object({<br>      enabled             = optional(bool, true)<br>      healthy_threshold   = optional(number, 2)<br>      unhealthy_threshold = optional(number, 2)<br>      timeout             = optional(number, 10)<br>      interval            = optional(number, 15)<br>      path                = optional(string, "/")<br>      port                = optional(string, "traffic-port")<br>      protocol            = optional(string)<br>      matcher             = optional(string, "200-399")<br>    }), {})<br>    <br>    stickiness = optional(object({<br>      enabled         = optional(bool, false)<br>      cookie_duration = optional(number, 86400)<br>    }))<br>    <br>    tags = optional(map(string), {})<br>  }))</pre> | `{}` | no |
| <a name="input_listener_rules"></a> [listener\_rules](#input\_listener\_rules) | Map of listener rules for routing traffic to different target groups | <pre>map(object({<br>    listener_type = string # "http" or "https"<br>    priority      = number<br>    target_group_key = string # Key from target_groups map<br>    <br>    conditions = list(object({<br>      field  = string # "host-header", "path-pattern", "http-request-method", etc.<br>      values = list(string)<br>    }))<br>    <br>    action_type = optional(string, "forward") # "forward", "redirect", "fixed-response"<br>    <br>    # For redirect actions<br>    redirect = optional(object({<br>      host        = optional(string, "#{host}")<br>      path        = optional(string, "/#{path}")<br>      port        = optional(string, "#{port}")<br>      protocol    = optional(string, "#{protocol}")<br>      query       = optional(string, "#{query}")<br>      status_code = string<br>    }))<br>    <br>    # For fixed-response actions<br>    fixed_response = optional(object({<br>      content_type = string<br>      message_body = optional(string)<br>      status_code  = string<br>    }))<br>  }))</pre> | `{}` | no |
| <a name="input_access_logs_enabled"></a> [access\_logs\_enabled](#input\_access\_logs\_enabled) | A boolean flag to enable/disable access\_logs | `bool` | `true` | no |
| <a name="input_deletion_protection_enabled"></a> [deletion\_protection\_enabled](#input\_deletion\_protection\_enabled) | A boolean flag to enable/disable deletion protection for ALB | `bool` | `false` | no |
| <a name="input_namespace"></a> [namespace](#input\_namespace) | ID element. Usually an abbreviation of your organization name, e.g. 'eg' or 'cp', to help ensure generated IDs are globally unique | `string` | `null` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | ID element. Usually used for region e.g. 'uw2', 'us-west-2', OR role 'prod', 'staging', 'dev', 'UAT' | `string` | `null` | no |
| <a name="input_stage"></a> [stage](#input\_stage) | ID element. Usually used to indicate role, e.g. 'prod', 'staging', 'source', 'build', 'test', 'deploy', 'release' | `string` | `null` | no |
| <a name="input_name"></a> [name](#input\_name) | ID element. Usually the component or solution name, e.g. 'app' or 'jenkins' | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Additional tags (e.g. `{'BusinessUnit': 'XYZ'}`). Neither the tag keys nor the tag values will be modified by this module | `map(string)` | `{}` | no |

<details>
<summary>Click to expand all input variables</summary>

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_security_group_ids"></a> [security\_group\_ids](#input\_security\_group\_ids) | A list of additional security group IDs to attach to the ALB | `list(string)` | `[]` | no |
| <a name="input_http_port"></a> [http\_port](#input\_http\_port) | The port for the HTTP listener | `number` | `80` | no |
| <a name="input_https_port"></a> [https\_port](#input\_https\_port) | The port for the HTTPS listener | `number` | `443` | no |
| <a name="input_https_ssl_policy"></a> [https\_ssl\_policy](#input\_https\_ssl\_policy) | The name of the SSL Policy for the listener | `string` | `"ELBSecurityPolicy-TLS13-1-2-2021-06"` | no |
| <a name="input_additional_certs"></a> [additional\_certs](#input\_additional\_certs) | A list of additonal certs to add to the https listerner | `list(string)` | `[]` | no |
| <a name="input_access_logs_prefix"></a> [access\_logs\_prefix](#input\_access\_logs\_prefix) | The S3 log bucket prefix | `string` | `""` | no |
| <a name="input_access_logs_s3_bucket_id"></a> [access\_logs\_s3\_bucket\_id](#input\_access\_logs\_s3\_bucket\_id) | An external S3 Bucket name to store access logs in. If specified, no logging bucket will be created. | `string` | `null` | no |
| <a name="input_cross_zone_load_balancing_enabled"></a> [cross\_zone\_load\_balancing\_enabled](#input\_cross\_zone\_load\_balancing\_enabled) | A boolean flag to enable/disable cross zone load balancing | `bool` | `true` | no |
| <a name="input_http2_enabled"></a> [http2\_enabled](#input\_http2\_enabled) | A boolean flag to enable/disable HTTP/2 | `bool` | `true` | no |
| <a name="input_idle_timeout"></a> [idle\_timeout](#input\_idle\_timeout) | The time in seconds that the connection is allowed to be idle | `number` | `60` | no |
| <a name="input_ip_address_type"></a> [ip\_address\_type](#input\_ip\_address\_type) | The type of IP addresses used by the subnets for your load balancer. The possible values are `ipv4` and `dualstack`. | `string` | `"ipv4"` | no |
| <a name="input_target_group_port"></a> [target\_group\_port](#input\_target\_group\_port) | The port for the default target group | `number` | `80` | no |
| <a name="input_target_group_protocol"></a> [target\_group\_protocol](#input\_target\_group\_protocol) | The protocol for the default target group HTTP or HTTPS | `string` | `"HTTP"` | no |
| <a name="input_target_group_target_type"></a> [target\_group\_target\_type](#input\_target\_group\_target\_type) | The type (`instance`, `ip` or `lambda`) of targets that can be registered with the target group | `string` | `"ip"` | no |
| <a name="input_health_check_path"></a> [health\_check\_path](#input\_health\_check\_path) | The destination for the health check request | `string` | `"/"` | no |
| <a name="input_health_check_timeout"></a> [health\_check\_timeout](#input\_health\_check\_timeout) | The amount of time to wait in seconds before failing a health check request | `number` | `10` | no |
| <a name="input_health_check_healthy_threshold"></a> [health\_check\_healthy\_threshold](#input\_health\_check\_healthy\_threshold) | The number of consecutive health checks successes required before considering an unhealthy target healthy | `number` | `2` | no |
| <a name="input_health_check_unhealthy_threshold"></a> [health\_check\_unhealthy\_threshold](#input\_health\_check\_unhealthy\_threshold) | The number of consecutive health check failures required before considering the target unhealthy | `number` | `2` | no |
| <a name="input_health_check_interval"></a> [health\_check\_interval](#input\_health\_check\_interval) | The duration in seconds in between health checks | `number` | `15` | no |
| <a name="input_health_check_matcher"></a> [health\_check\_matcher](#input\_health\_check\_matcher) | The HTTP response codes to indicate a healthy check | `string` | `"200-399"` | no |
| <a name="input_default_target_group_enabled"></a> [default\_target\_group\_enabled](#input\_default\_target\_group\_enabled) | Whether the default target group should be created or not. | `bool` | `true` | no |
| <a name="input_delimiter"></a> [delimiter](#input\_delimiter) | Delimiter to be used between ID elements. Defaults to `-` (hyphen). Set to `""` to use no delimiter at all | `string` | `"-"` | no |

</details>

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_alb_arn"></a> [alb\_arn](#output\_alb\_arn) | The ARN of the ALB |
| <a name="output_alb_dns_name"></a> [alb\_dns\_name](#output\_alb\_dns\_name) | DNS name of ALB |
| <a name="output_alb_zone_id"></a> [alb\_zone\_id](#output\_alb\_zone\_id) | The ID of the zone which ALB is provisioned |
| <a name="output_security_group_id"></a> [security\_group\_id](#output\_security\_group\_id) | The security group ID of the ALB |
| <a name="output_target_group_arns"></a> [target\_group\_arns](#output\_target\_group\_arns) | Map of target group ARNs (key = target group name, value = ARN) |
| <a name="output_listener_arns"></a> [listener\_arns](#output\_listener\_arns) | A list of all the listener ARNs |
| <a name="output_access_logs_bucket_id"></a> [access\_logs\_bucket\_id](#output\_access\_logs\_bucket\_id) | The S3 bucket ID for access logs |
| <a name="output_vpc_id"></a> [vpc\_id](#output\_vpc\_id) | The VPC ID used by the ALB |
| <a name="output_subnet_ids"></a> [subnet\_ids](#output\_subnet\_ids) | The subnet IDs used by the ALB |

<details>
<summary>Click to expand all outputs</summary>

| Name | Description |
|------|-------------|
| <a name="output_alb_name"></a> [alb\_name](#output\_alb\_name) | The ARN suffix of the ALB |
| <a name="output_alb_arn_suffix"></a> [alb\_arn\_suffix](#output\_alb\_arn\_suffix) | The ARN suffix of the ALB |
| <a name="output_default_target_group_arn"></a> [default\_target\_group\_arn](#output\_default\_target\_group\_arn) | The default target group ARN |
| <a name="output_default_target_group_arn_suffix"></a> [default\_target\_group\_arn\_suffix](#output\_default\_target\_group\_arn\_suffix) | The default target group ARN suffix |
| <a name="output_http_listener_arn"></a> [http\_listener\_arn](#output\_http\_listener\_arn) | The ARN of the HTTP forwarding listener |
| <a name="output_http_redirect_listener_arn"></a> [http\_redirect\_listener\_arn](#output\_http\_redirect\_listener\_arn) | The ARN of the HTTP to HTTPS redirect listener |
| <a name="output_https_listener_arn"></a> [https\_listener\_arn](#output\_https\_listener\_arn) | The ARN of the HTTPS listener |
| <a name="output_target_groups"></a> [target\_groups](#output\_target\_groups) | Map of additional target groups created |
| <a name="output_listener_rules"></a> [listener\_rules](#output\_listener\_rules) | Map of listener rules created |

</details>

## Target Group Configuration

### Basic Target Group

```hcl
target_groups = {
  web = {
    port         = 80
    protocol     = "HTTP"
    target_type  = "instance"
    
    health_check = {
      path     = "/health"
      matcher  = "200"
      interval = 30
      timeout  = 5
    }
  }
}
```

### Advanced Target Group with Stickiness

```hcl
target_groups = {
  app = {
    port                          = 8080
    protocol                      = "HTTP"
    target_type                   = "ip"
    load_balancing_algorithm_type = "weighted_random"
    deregistration_delay          = 60
    
    health_check = {
      path                = "/api/health"
      healthy_threshold   = 3
      unhealthy_threshold = 2
      timeout             = 10
      interval            = 30
      matcher             = "200,202"
    }
    
    stickiness = {
      enabled         = true
      cookie_duration = 3600
    }
    
    tags = {
      Service = "backend-api"
      Team    = "platform"
    }
  }
}
```

## Listener Rules Configuration

### Path-based Routing

```hcl
listener_rules = {
  api_rule = {
    listener_type    = "https"
    priority         = 100
    target_group_key = "api"
    
    conditions = [
      {
        field  = "path-pattern"
        values = ["/api/*"]
      }
    ]
  }
}
```

### Host-based Routing

```hcl
listener_rules = {
  subdomain_rule = {
    listener_type    = "https"
    priority         = 200
    target_group_key = "api"
    
    conditions = [
      {
        field  = "host-header"
        values = ["api.example.com", "api-v2.example.com"]
      }
    ]
  }
}
```

### Redirect Rule

```hcl
listener_rules = {
  redirect_rule = {
    listener_type = "https"
    priority      = 300
    action_type   = "redirect"
    
    conditions = [
      {
        field  = "path-pattern"
        values = ["/old-api/*"]
      }
    ]
    
    redirect = {
      path        = "/api/v2/#{path}"
      status_code = "HTTP_301"
    }
  }
}
```

## Security Considerations

### SSL/TLS Configuration

- Uses modern SSL policy `ELBSecurityPolicy-TLS13-1-2-2021-06` by default
- Supports multiple certificates for SNI
- HTTP to HTTPS redirect available

### Security Groups

- Automatic security group creation with minimal required rules
- Support for additional security groups
- Configurable ingress CIDR blocks and security group references

### Access Logs

- S3 bucket with encryption and secure access policies
- Configurable log prefix and lifecycle rules
- Option to use existing S3 bucket

## Performance Features

- **HTTP/2 Support**: Enabled by default for better performance
- **Cross-Zone Load Balancing**: Distributes traffic evenly across AZs
- **Connection Draining**: Configurable deregistration delay
- **Health Checks**: Comprehensive health check configuration
- **Load Balancing Algorithms**: Round robin, least outstanding requests, weighted random

## Monitoring and Observability

### CloudWatch Integration

The ALB automatically publishes metrics to CloudWatch:

- Request count and latency
- Target response times
- HTTP error rates
- Active connection count

### Access Logs

Access logs are stored in S3 and include:

- Request timestamp and client IP
- Request and response details
- Target processing time
- SSL cipher and protocol information

## Migration Guide

### From CloudPosse Module

This module replaces CloudPosse dependencies with native AWS resources:

```hcl
# Old CloudPosse approach
module "alb" {
  source = "cloudposse/alb/aws"
  
  context = module.this.context
  # ... other config
}

# New approach
module "alb" {
  source = "path/to/this/module"
  
  namespace   = "mycompany"
  environment = "prod"
  name        = "web-alb"
  # ... other config
}
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests and documentation
5. Submit a pull request

## License

This module is licensed under the MIT License. See [LICENSE](LICENSE) for full details.

## Authors

Created and maintained by the Platform Engineering Team.

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for release history and changes.