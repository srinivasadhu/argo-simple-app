# Basic ALB Example

This example demonstrates the simplest way to use the ALB module. It creates an Application Load Balancer with a single default target group, perfect for getting started or simple single-service deployments.

## What This Example Creates

- **Application Load Balancer** with HTTP listener (HTTPS optional)
- **Default Target Group** for your application
- **Security Group** with appropriate ingress/egress rules
- **S3 Bucket** for access logs (with encryption and lifecycle policies)

## Architecture

```
Internet → ALB (HTTP/HTTPS) → Default Target Group → Your Application
```

## Prerequisites

- **Existing VPC** with at least 2 subnets in different Availability Zones
- **AWS CLI** configured with appropriate permissions
- **Terraform >= 1.3** installed
- **SSL Certificate** in AWS Certificate Manager (only if enabling HTTPS)

## Quick Start

### 1. Navigate to Example Directory
```bash
cd examples/basic/
```

### 2. Copy Configuration Template
```bash
cp terraform.tfvars.example terraform.tfvars
```

### 3. Update Required Variables
Edit `terraform.tfvars` and update these **required** values:

```hcl
# REQUIRED: Replace with your actual VPC ID
vpc_id = "vpc-your-actual-vpc-id"

# REQUIRED: Replace with your actual subnet IDs (minimum 2, different AZs)
subnet_ids = [
  "subnet-your-subnet-1",  # Must be in different AZ
  "subnet-your-subnet-2"   # Must be in different AZ
]
```

### 4. Deploy
```bash
terraform init
terraform plan
terraform apply
```

### 5. Note the Outputs
After deployment, Terraform will output important values:
- `alb_dns_name` - Use this for DNS records
- `target_group_arn` - Use this to register your instances
- `security_group_id` - Allow traffic from this SG to your instances

## Configuration Options

### Basic HTTP-Only Setup (Default)
```hcl
http_enabled  = true
https_enabled = false
```

### HTTPS-Only Setup
```hcl
http_enabled    = false
https_enabled   = true
certificate_arn = "arn:aws:acm:region:account:certificate/cert-id"
```

### HTTP with HTTPS Redirect (Recommended)
```hcl
http_enabled    = true
http_redirect   = true  # Add this to main.tf if needed
https_enabled   = true
certificate_arn = "arn:aws:acm:region:account:certificate/cert-id"
```

### Target Group Types

#### For EC2 Instances
```hcl
target_group_target_type = "instance"
target_group_port        = 80
```

#### For ECS/Fargate Containers
```hcl
target_group_target_type = "ip"
target_group_port        = 8080
```

#### For Lambda Functions
```hcl
target_group_target_type = "lambda"
# Port not applicable for Lambda
```

## Post-Deployment Steps

### 1. Register Targets with Target Group

#### For EC2 Instances
```bash
# Get the target group ARN from Terraform output
TARGET_GROUP_ARN=$(terraform output -raw target_group_arn)

# Register your EC2 instances
aws elbv2 register-targets \
  --target-group-arn $TARGET_GROUP_ARN \
  --targets Id=i-1234567890abcdef0,Port=80 Id=i-0987654321fedcba0,Port=80
```

#### For ECS Services
```hcl
resource "aws_ecs_service" "app" {
  # ... other configuration
  
  load_balancer {
    target_group_arn = module.alb.default_target_group_arn
    container_name   = "my-app"
    container_port   = 80
  }
}
```

### 2. Configure Security Groups

Allow traffic from ALB to your application instances:

```hcl
resource "aws_security_group_rule" "app_from_alb" {
  type                     = "ingress"
  from_port                = 80
  to_port                  = 80
  protocol                 = "tcp"
  source_security_group_id = module.alb.security_group_id
  security_group_id        = var.app_security_group_id
}
```

### 3. Configure DNS

#### Using Route53
```hcl
resource "aws_route53_record" "app" {
  zone_id = var.hosted_zone_id
  name    = "app.example.com"
  type    = "A"

  alias {
    name                   = module.alb.alb_dns_name
    zone_id                = module.alb.alb_zone_id
    evaluate_target_health = true
  }
}
```

#### Manual DNS Configuration
Create an A record (or CNAME) pointing to the ALB DNS name:
```
app.example.com → your-alb-dns-name.region.elb.amazonaws.com
```

## Testing

### 1. Check ALB Status
```bash
# Get ALB DNS name
ALB_DNS=$(terraform output -raw alb_dns_name)

# Test HTTP endpoint
curl http://$ALB_DNS/

# Test HTTPS endpoint (if enabled)
curl https://$ALB_DNS/
```

### 2. Check Target Health
```bash
# Get target group ARN
TARGET_GROUP_ARN=$(terraform output -raw target_group_arn)

# Check target health
aws elbv2 describe-target-health --target-group-arn $TARGET_GROUP_ARN
```

## Customization Examples

### Custom Health Check
```hcl
health_check_path                = "/health"
health_check_healthy_threshold   = 3
health_check_unhealthy_threshold = 2
health_check_interval            = 15
health_check_timeout             = 10
health_check_matcher             = "200,202"
```

### Production Security Settings
```hcl
deletion_protection_enabled = true
access_logs_enabled        = true
```

### Custom Naming
```hcl
namespace   = "acme"
environment = "prod"
name        = "api"
# Results in ALB name: acme-prod-api
```

## Monitoring

### CloudWatch Metrics
The ALB automatically publishes metrics to CloudWatch:
- `RequestCount` - Number of requests
- `TargetResponseTime` - Response time from targets
- `HTTPCode_Target_2XX_Count` - Successful responses
- `UnHealthyHostCount` - Number of unhealthy targets

### Access Logs
Access logs are stored in the created S3 bucket with the configured prefix. Use AWS Athena or other tools to analyze traffic patterns.

## Troubleshooting

### Common Issues

1. **Targets showing as unhealthy**
   - Check security groups allow traffic from ALB
   - Verify health check path returns 200 status
   - Check application is listening on correct port

2. **Cannot access ALB**
   - Verify subnets are public (for internet-facing ALB)
   - Check route tables have internet gateway route
   - Verify security groups allow inbound traffic

3. **SSL certificate errors**
   - Certificate must be in same region as ALB
   - Certificate status must be "Issued"
   - Domain name must match certificate

### Debug Commands
```bash
# Check ALB status
aws elbv2 describe-load-balancers --names <alb-name>

# Check target group health
aws elbv2 describe-target-health --target-group-arn <arn>

# Check security group rules
aws ec2 describe-security-groups --group-ids <sg-id>
```

## Clean Up

```bash
terraform destroy
```

**Note**: The S3 bucket for access logs will be deleted. If you want to preserve logs, set `alb_access_logs_s3_bucket_force_destroy = false` before destroying.

## Next Steps

- **Add more targets**: Register additional EC2 instances or containers
- **Enable HTTPS**: Add SSL certificate and enable HTTPS listener
- **Add monitoring**: Set up CloudWatch alarms for key metrics
- **Advanced routing**: Upgrade to [multi-target-group example](../multi_target_group_alb/) for path-based routing
- **Auto Scaling**: Integrate with Auto Scaling Groups for automatic scaling

## Variables Reference

### Required Variables
| Variable | Description |
|----------|-------------|
| `vpc_id` | VPC ID where ALB will be created |
| `subnet_ids` | List of subnet IDs (minimum 2, different AZs) |

### Optional Variables
| Variable | Default | Description |
|----------|---------|-------------|
| `internal` | `false` | Create internal ALB (private subnets) |
| `http_enabled` | `true` | Enable HTTP listener |
| `https_enabled` | `false` | Enable HTTPS listener |
| `target_group_port` | `80` | Port for target group |
| `health_check_path` | `"/"` | Health check endpoint |
| `deletion_protection_enabled` | `false` | Enable deletion protection |

See [variables.tf](./variables.tf) for complete list of variables and their descriptions.