# ALB Module with Auto-Discovery Example

This example demonstrates how to use the ALB module with automatic resource discovery. Simply provide a VPC name, and the module will automatically find and use all public subnets in that VPC.

## Features Demonstrated

- **VPC Discovery**: Automatically find VPC by name tag
- **Auto-Discovery of Public Subnets**: Automatically find all public subnets in the VPC (default behavior)
- **Multiple Subnet Discovery Methods**: 
  - Auto-discovery (recommended - finds public subnets automatically)
  - By subnet names (Name tags)
  - By tag filters (e.g., Type=public, Tier=web)
  - Traditional approach with explicit IDs
- **Multiple ALB Configurations**: Shows different ways to configure the same module

## Prerequisites

Before running this example, ensure you have:

1. **Existing VPC** with proper Name tag
2. **Existing Subnets** with proper Name tags and/or other identifying tags
3. **SSL Certificate** (if enabling HTTPS) in AWS Certificate Manager
4. **Proper AWS credentials** configured
5. **Terraform >= 1.0** installed

## VPC and Subnet Tagging Requirements

### VPC Tags
Your VPC should have a Name tag:
```
Name = "my-production-vpc"
```

### Subnet Tags (for auto-discovery)
For automatic public subnet discovery, your public subnets should have:
```
Type = "public"  # Default tag for auto-discovery
```

### Alternative Subnet Tags
If using explicit discovery methods:

**Option 1: Using Name tags**
```
Name = "my-production-vpc-public-subnet-1"
Name = "my-production-vpc-public-subnet-2"
```

**Option 2: Using custom type/tier tags**
```
Type = "public"
Tier = "web"
```

## Usage

### 1. Copy the example configuration
```bash
cp terraform.tfvars.example terraform.tfvars
```

### 2. Edit terraform.tfvars
Update the variables to match your environment:

```hcl
# Required: VPC identification
vpc_name = "your-vpc-name"

# Required: Subnet identification (choose one method)
public_subnet_names = [
  "your-public-subnet-1",
  "your-public-subnet-2"
]

# Optional: HTTPS configuration
enable_https = true
certificate_arn = "arn:aws:acm:region:account:certificate/cert-id"
```

### 3. Initialize and apply
```bash
terraform init
terraform plan
terraform apply
```

## Configuration Methods

### Method 1: Auto-Discovery (Recommended - Simplest)
```hcl
module "alb_auto_discovery" {
  source = "../.."
  
  # Only VPC name required - public subnets auto-discovered
  vpc_name = "my-production-vpc"
  
  # Optional: customize auto-discovery
  # auto_discover_public_subnets = true  # default
  # public_subnet_tag_key = "Type"       # default
  # public_subnet_tag_value = "public"   # default
  
  # ... other configuration
}
```

### Method 2: VPC Name + Explicit Subnet Names
```hcl
module "alb_with_names" {
  source = "../.."
  
  vpc_name     = "my-production-vpc"
  subnet_names = [
    "my-production-vpc-public-subnet-1",
    "my-production-vpc-public-subnet-2"
  ]
  
  # ... other configuration
}
```

### Method 3: VPC Name + Subnet Tag Filters
```hcl
module "alb_with_tag_filters" {
  source = "../.."
  
  vpc_name = "my-production-vpc"
  subnet_tag_filter = {
    Type = "public"
    Tier = "web"
  }
  
  # ... other configuration
}
```

### Method 4: Traditional with IDs
```hcl
module "alb_with_ids" {
  source = "../.."
  
  vpc_id     = "vpc-12345678"
  subnet_ids = ["subnet-12345678", "subnet-87654321"]
  
  # ... other configuration
}
```

## Required Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `vpc_name` | Name of existing VPC | `"my-production-vpc"` |

**That's it!** With auto-discovery enabled (default), you only need to provide the VPC name.

## Optional Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `auto_discover_public_subnets` | Auto-discover public subnets | `true` |
| `public_subnet_tag_key` | Tag key for public subnet discovery | `"Type"` |
| `public_subnet_tag_value` | Tag value for public subnet discovery | `"public"` |
| `enable_https` | Enable HTTPS listener | `true` |
| `certificate_arn` | SSL certificate ARN | `""` |
| `target_group_port` | Target group port | `80` |
| `health_check_path` | Health check endpoint | `"/health"` |
| `access_logs_enabled` | Enable access logs | `true` |

## Outputs

| Output | Description |
|--------|-------------|
| `alb_dns_name` | ALB DNS name for routing traffic |
| `alb_arn` | ALB ARN for reference |
| `target_group_arn` | Target group ARN for EC2 attachments |
| `vpc_id` | Discovered VPC ID |
| `subnet_ids` | Discovered subnet IDs |
| `auto_discovered_subnets` | Whether subnets were auto-discovered |
| `subnet_discovery_method` | Method used to discover subnets |

## Integration with EC2 Instances

After creating the ALB, you can attach EC2 instances:

```hcl
resource "aws_lb_target_group_attachment" "web_servers" {
  count            = length(var.instance_ids)
  target_group_arn = module.alb_with_names.target_group_arn
  target_id        = var.instance_ids[count.index]
  port             = 80
}
```

## Troubleshooting

### Common Issues

1. **VPC not found**
   - Verify VPC exists and has correct Name tag
   - Check AWS region

2. **No subnets found**
   - Verify subnets exist in the specified VPC
   - Check subnet tags match your filters
   - Ensure subnets are in different AZs for ALB

3. **Certificate issues**
   - Verify certificate exists in same region
   - Check certificate status is "Issued"

### Debug Commands

```bash
# Check VPC
aws ec2 describe-vpcs --filters "Name=tag:Name,Values=my-production-vpc"

# Check subnets
aws ec2 describe-subnets --filters "Name=vpc-id,Values=vpc-12345678" "Name=tag:Type,Values=public"

# Check certificate
aws acm list-certificates --region us-west-2
```

## Clean Up

```bash
terraform destroy
```

## Next Steps

- Integrate with EC2 instances or ECS services
- Add custom listener rules for path-based routing
- Configure additional target groups for different services
- Set up CloudWatch alarms for monitoring